﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class addClientBtn : Form
    {
        public addClientBtn()
        {
            InitializeComponent();
        }

        private void клиентыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.клиентыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.myBD_VerbitskiyKurDataSet);

        }

        private void addClientBtn_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Клиенты);

        }


        int getMaxID()
        {

            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\MyBD_VerbitskiyKur.mdf;Integrated Security=True;Connect Timeout=30");

            SqlCommand cmd = new SqlCommand($"SELECT MAX(Код_клиента) FROM Клиенты");
            cmd.Connection = con;

            con.Open();

            int id = 0;
            using (SqlDataReader r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    id = r.GetInt32(0);
                }
            }

            con.Close();



            return id;
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            MyBD_VerbitskiyKurDataSet.КлиентыRow r = this.myBD_VerbitskiyKurDataSet.Клиенты.NewКлиентыRow();

            int id = getMaxID();

            if (id != 0)
            {
                r.Код_клиента = id + 1;
                r.Фамилия = sNameTB.Text;
                r.Имя = nameTB.Text;
                r.Отчество = tNameTB.Text;

                try
                {
                    r.Номер_паспорта = Convert.ToInt32(numberTB.Text);
                    r.Серия = Convert.ToInt32(seriaTB.Text);
                    r.Дата_выдачи = Convert.ToInt32(dateTB.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                    return;
                }

                myBD_VerbitskiyKurDataSet.Клиенты.AddКлиентыRow(r);
                клиентыTableAdapter.Update(myBD_VerbitskiyKurDataSet.Клиенты);

            }
            else
            {
                MessageBox.Show("Error!");
            }


            this.Close();
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
