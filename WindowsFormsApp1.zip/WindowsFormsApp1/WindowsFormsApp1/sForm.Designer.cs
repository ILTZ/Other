﻿namespace WindowsFormsApp1
{
    partial class sForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.normSdachaDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.normSdachaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myBD_VerbitskiyKurDataSet = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSet();
            this.label1 = new System.Windows.Forms.Label();
            this.normSdachaTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.normSdachaTableAdapter();
            this.tableAdapterManager = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager();
            this.addBtn = new System.Windows.Forms.Button();
            this.delBtn = new System.Windows.Forms.Button();
            this.statBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.sortBtn = new System.Windows.Forms.Button();
            this.botRB = new System.Windows.Forms.RadioButton();
            this.upRB = new System.Windows.Forms.RadioButton();
            this.critLB = new System.Windows.Forms.ListBox();
            this.closeBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.normSdachaDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.normSdachaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // normSdachaDataGridView
            // 
            this.normSdachaDataGridView.AutoGenerateColumns = false;
            this.normSdachaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.normSdachaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.normSdachaDataGridView.DataSource = this.normSdachaBindingSource;
            this.normSdachaDataGridView.Location = new System.Drawing.Point(-1, 60);
            this.normSdachaDataGridView.Name = "normSdachaDataGridView";
            this.normSdachaDataGridView.Size = new System.Drawing.Size(946, 220);
            this.normSdachaDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Код_сдачи";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код_сдачи";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Название";
            this.dataGridViewTextBoxColumn2.HeaderText = "Название";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Фамилия";
            this.dataGridViewTextBoxColumn3.HeaderText = "Фамилия";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Имя";
            this.dataGridViewTextBoxColumn4.HeaderText = "Имя";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Отчество";
            this.dataGridViewTextBoxColumn5.HeaderText = "Отчество";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Описание";
            this.dataGridViewTextBoxColumn6.HeaderText = "Описание";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Дата_сдачи";
            this.dataGridViewTextBoxColumn7.HeaderText = "Дата_сдачи";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Сумма_на_руки";
            this.dataGridViewTextBoxColumn8.HeaderText = "Сумма_на_руки";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Комиссионные";
            this.dataGridViewTextBoxColumn9.HeaderText = "Комиссионные";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // normSdachaBindingSource
            // 
            this.normSdachaBindingSource.DataMember = "normSdacha";
            this.normSdachaBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // myBD_VerbitskiyKurDataSet
            // 
            this.myBD_VerbitskiyKurDataSet.DataSetName = "MyBD_VerbitskiyKurDataSet";
            this.myBD_VerbitskiyKurDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(-1, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(946, 48);
            this.label1.TabIndex = 7;
            this.label1.Text = "Сдача в ломбард";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // normSdachaTableAdapter
            // 
            this.normSdachaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.Категория_товаровTableAdapter = null;
            this.tableAdapterManager.КлиентыTableAdapter = null;
            this.tableAdapterManager.ПродажиTableAdapter = null;
            this.tableAdapterManager.Сдача_в_ломбардTableAdapter = null;
            this.tableAdapterManager.ЦеныTableAdapter = null;
            // 
            // addBtn
            // 
            this.addBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addBtn.Location = new System.Drawing.Point(12, 286);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(151, 57);
            this.addBtn.TabIndex = 11;
            this.addBtn.Text = "Добавить";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // delBtn
            // 
            this.delBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.delBtn.Location = new System.Drawing.Point(169, 286);
            this.delBtn.Name = "delBtn";
            this.delBtn.Size = new System.Drawing.Size(151, 57);
            this.delBtn.TabIndex = 12;
            this.delBtn.Text = "Удалить";
            this.delBtn.UseVisualStyleBackColor = true;
            this.delBtn.Click += new System.EventHandler(this.delBtn_Click);
            // 
            // statBtn
            // 
            this.statBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.statBtn.Location = new System.Drawing.Point(6, 226);
            this.statBtn.Name = "statBtn";
            this.statBtn.Size = new System.Drawing.Size(339, 57);
            this.statBtn.TabIndex = 13;
            this.statBtn.Text = "Статистика";
            this.statBtn.UseVisualStyleBackColor = true;
            this.statBtn.Click += new System.EventHandler(this.statBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.sortBtn);
            this.groupBox1.Controls.Add(this.statBtn);
            this.groupBox1.Controls.Add(this.botRB);
            this.groupBox1.Controls.Add(this.upRB);
            this.groupBox1.Controls.Add(this.critLB);
            this.groupBox1.Location = new System.Drawing.Point(951, 60);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(354, 293);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Сортировка";
            // 
            // sortBtn
            // 
            this.sortBtn.Enabled = false;
            this.sortBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sortBtn.Location = new System.Drawing.Point(6, 166);
            this.sortBtn.Name = "sortBtn";
            this.sortBtn.Size = new System.Drawing.Size(339, 57);
            this.sortBtn.TabIndex = 15;
            this.sortBtn.Text = "Сортировать";
            this.sortBtn.UseVisualStyleBackColor = true;
            this.sortBtn.Click += new System.EventHandler(this.sortBtn_Click);
            // 
            // botRB
            // 
            this.botRB.AutoSize = true;
            this.botRB.Location = new System.Drawing.Point(6, 143);
            this.botRB.Name = "botRB";
            this.botRB.Size = new System.Drawing.Size(93, 17);
            this.botRB.TabIndex = 2;
            this.botRB.Text = "По убыванию";
            this.botRB.UseVisualStyleBackColor = true;
            // 
            // upRB
            // 
            this.upRB.AutoSize = true;
            this.upRB.Checked = true;
            this.upRB.Location = new System.Drawing.Point(6, 120);
            this.upRB.Name = "upRB";
            this.upRB.Size = new System.Drawing.Size(109, 17);
            this.upRB.TabIndex = 1;
            this.upRB.TabStop = true;
            this.upRB.Text = "По возрастанию";
            this.upRB.UseVisualStyleBackColor = true;
            // 
            // critLB
            // 
            this.critLB.FormattingEnabled = true;
            this.critLB.Items.AddRange(new object[] {
            "Название",
            "Сумма на руки",
            "Комиссионные"});
            this.critLB.Location = new System.Drawing.Point(6, 19);
            this.critLB.Name = "critLB";
            this.critLB.Size = new System.Drawing.Size(339, 95);
            this.critLB.TabIndex = 0;
            this.critLB.SelectedIndexChanged += new System.EventHandler(this.critLB_SelectedIndexChanged);
            // 
            // closeBtn
            // 
            this.closeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.closeBtn.Location = new System.Drawing.Point(794, 286);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(151, 57);
            this.closeBtn.TabIndex = 15;
            this.closeBtn.Text = "Закрыть";
            this.closeBtn.UseVisualStyleBackColor = true;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // sForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1308, 354);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.delBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.normSdachaDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "sForm";
            this.Text = "Сдача в ломбард";
            this.Activated += new System.EventHandler(this.sForm_Activated);
            this.Load += new System.EventHandler(this.sForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.normSdachaDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.normSdachaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MyBD_VerbitskiyKurDataSet myBD_VerbitskiyKurDataSet;
        private System.Windows.Forms.BindingSource normSdachaBindingSource;
        private MyBD_VerbitskiyKurDataSetTableAdapters.normSdachaTableAdapter normSdachaTableAdapter;
        private MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView normSdachaDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button delBtn;
        private System.Windows.Forms.Button statBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button sortBtn;
        private System.Windows.Forms.RadioButton botRB;
        private System.Windows.Forms.RadioButton upRB;
        private System.Windows.Forms.ListBox critLB;
        private System.Windows.Forms.Button closeBtn;
    }
}