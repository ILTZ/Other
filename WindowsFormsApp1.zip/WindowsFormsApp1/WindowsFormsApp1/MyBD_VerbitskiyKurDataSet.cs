﻿namespace WindowsFormsApp1
{


    partial class MyBD_VerbitskiyKurDataSet
    {
    }
}
