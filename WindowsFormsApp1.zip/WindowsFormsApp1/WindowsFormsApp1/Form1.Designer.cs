﻿namespace WindowsFormsApp1
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.PriceBtn = new System.Windows.Forms.Button();
            this.CategoryBtn = new System.Windows.Forms.Button();
            this.ClientsBtn = new System.Windows.Forms.Button();
            this.sdachaBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // PriceBtn
            // 
            this.PriceBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PriceBtn.Location = new System.Drawing.Point(266, 181);
            this.PriceBtn.Name = "PriceBtn";
            this.PriceBtn.Size = new System.Drawing.Size(151, 57);
            this.PriceBtn.TabIndex = 10;
            this.PriceBtn.Text = "Цены";
            this.PriceBtn.UseVisualStyleBackColor = true;
            this.PriceBtn.Click += new System.EventHandler(this.PriceBtn_Click);
            // 
            // CategoryBtn
            // 
            this.CategoryBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CategoryBtn.Location = new System.Drawing.Point(266, 330);
            this.CategoryBtn.Name = "CategoryBtn";
            this.CategoryBtn.Size = new System.Drawing.Size(151, 57);
            this.CategoryBtn.TabIndex = 9;
            this.CategoryBtn.Text = "Категории товаров";
            this.CategoryBtn.UseVisualStyleBackColor = true;
            this.CategoryBtn.Click += new System.EventHandler(this.CategoryBtn_Click);
            // 
            // ClientsBtn
            // 
            this.ClientsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ClientsBtn.Location = new System.Drawing.Point(266, 267);
            this.ClientsBtn.Name = "ClientsBtn";
            this.ClientsBtn.Size = new System.Drawing.Size(151, 57);
            this.ClientsBtn.TabIndex = 8;
            this.ClientsBtn.Text = "Клиенты";
            this.ClientsBtn.UseVisualStyleBackColor = true;
            this.ClientsBtn.Click += new System.EventHandler(this.ClientsBtn_Click);
            // 
            // sdachaBtn
            // 
            this.sdachaBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.sdachaBtn.Location = new System.Drawing.Point(266, 118);
            this.sdachaBtn.Name = "sdachaBtn";
            this.sdachaBtn.Size = new System.Drawing.Size(151, 57);
            this.sdachaBtn.TabIndex = 7;
            this.sdachaBtn.Text = "Сдача в ломбард";
            this.sdachaBtn.UseVisualStyleBackColor = true;
            this.sdachaBtn.Click += new System.EventHandler(this.sdachaBtn_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(-51, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(780, 61);
            this.label1.TabIndex = 6;
            this.label1.Text = "Ломабрад \"У Яна\"";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 512);
            this.Controls.Add(this.PriceBtn);
            this.Controls.Add(this.CategoryBtn);
            this.Controls.Add(this.ClientsBtn);
            this.Controls.Add(this.sdachaBtn);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.Text = "Главная форма";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button PriceBtn;
        private System.Windows.Forms.Button CategoryBtn;
        private System.Windows.Forms.Button ClientsBtn;
        private System.Windows.Forms.Button sdachaBtn;
        private System.Windows.Forms.Label label1;
    }
}

