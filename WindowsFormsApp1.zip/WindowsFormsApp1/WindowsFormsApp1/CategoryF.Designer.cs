﻿namespace WindowsFormsApp1
{
    partial class CategoryF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.myBD_VerbitskiyKurDataSet = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSet();
            this.категория_товаровBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.категория_товаровTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.Категория_товаровTableAdapter();
            this.tableAdapterManager = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager();
            this.категория_товаровDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.addBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.deleteBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.категория_товаровBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.категория_товаровDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // myBD_VerbitskiyKurDataSet
            // 
            this.myBD_VerbitskiyKurDataSet.DataSetName = "MyBD_VerbitskiyKurDataSet";
            this.myBD_VerbitskiyKurDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // категория_товаровBindingSource
            // 
            this.категория_товаровBindingSource.DataMember = "Категория_товаров";
            this.категория_товаровBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // категория_товаровTableAdapter
            // 
            this.категория_товаровTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.Категория_товаровTableAdapter = this.категория_товаровTableAdapter;
            this.tableAdapterManager.КлиентыTableAdapter = null;
            this.tableAdapterManager.ПродажиTableAdapter = null;
            this.tableAdapterManager.Сдача_в_ломбардTableAdapter = null;
            this.tableAdapterManager.ЦеныTableAdapter = null;
            // 
            // категория_товаровDataGridView
            // 
            this.категория_товаровDataGridView.AutoGenerateColumns = false;
            this.категория_товаровDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.категория_товаровDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.категория_товаровDataGridView.DataSource = this.категория_товаровBindingSource;
            this.категория_товаровDataGridView.Location = new System.Drawing.Point(12, 46);
            this.категория_товаровDataGridView.Name = "категория_товаровDataGridView";
            this.категория_товаровDataGridView.Size = new System.Drawing.Size(642, 216);
            this.категория_товаровDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Код_категории";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код_категории";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Название";
            this.dataGridViewTextBoxColumn2.HeaderText = "Название";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn3.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // CloseBtn
            // 
            this.CloseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseBtn.Location = new System.Drawing.Point(503, 283);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(151, 57);
            this.CloseBtn.TabIndex = 9;
            this.CloseBtn.Text = "Закрыть";
            this.CloseBtn.UseVisualStyleBackColor = true;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // addBtn
            // 
            this.addBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addBtn.Location = new System.Drawing.Point(12, 283);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(151, 57);
            this.addBtn.TabIndex = 10;
            this.addBtn.Text = "Добавить";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(642, 34);
            this.label1.TabIndex = 11;
            this.label1.Text = "Категории";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // deleteBtn
            // 
            this.deleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.deleteBtn.Location = new System.Drawing.Point(169, 283);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(151, 57);
            this.deleteBtn.TabIndex = 12;
            this.deleteBtn.Text = "Удалить";
            this.deleteBtn.UseVisualStyleBackColor = true;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // CategoryF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 352);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.CloseBtn);
            this.Controls.Add(this.категория_товаровDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CategoryF";
            this.Text = "Категории товаров";
            this.Activated += new System.EventHandler(this.CategoryF_Activated);
            this.Load += new System.EventHandler(this.CategoryF_Load);
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.категория_товаровBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.категория_товаровDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MyBD_VerbitskiyKurDataSet myBD_VerbitskiyKurDataSet;
        private System.Windows.Forms.BindingSource категория_товаровBindingSource;
        private MyBD_VerbitskiyKurDataSetTableAdapters.Категория_товаровTableAdapter категория_товаровTableAdapter;
        private MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView категория_товаровDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button deleteBtn;
    }
}