﻿namespace WindowsFormsApp1
{
    partial class PriceF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.myBD_VerbitskiyKurDataSet = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSet();
            this.ценыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ценыTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.ЦеныTableAdapter();
            this.tableAdapterManager = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager();
            this.ценыDataGridView = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.closeBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ценыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ценыDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // myBD_VerbitskiyKurDataSet
            // 
            this.myBD_VerbitskiyKurDataSet.DataSetName = "MyBD_VerbitskiyKurDataSet";
            this.myBD_VerbitskiyKurDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ценыBindingSource
            // 
            this.ценыBindingSource.DataMember = "Цены";
            this.ценыBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // ценыTableAdapter
            // 
            this.ценыTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.Категория_товаровTableAdapter = null;
            this.tableAdapterManager.КлиентыTableAdapter = null;
            this.tableAdapterManager.ПродажиTableAdapter = null;
            this.tableAdapterManager.Сдача_в_ломбардTableAdapter = null;
            this.tableAdapterManager.ЦеныTableAdapter = this.ценыTableAdapter;
            // 
            // ценыDataGridView
            // 
            this.ценыDataGridView.AutoGenerateColumns = false;
            this.ценыDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ценыDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.ценыDataGridView.DataSource = this.ценыBindingSource;
            this.ценыDataGridView.Location = new System.Drawing.Point(12, 73);
            this.ценыDataGridView.Name = "ценыDataGridView";
            this.ценыDataGridView.Size = new System.Drawing.Size(592, 220);
            this.ценыDataGridView.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(592, 61);
            this.label1.TabIndex = 7;
            this.label1.Text = "Продажи";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Код_сдачи";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код_сдачи";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 200;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Дата";
            this.dataGridViewTextBoxColumn2.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 200;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Цена";
            this.dataGridViewTextBoxColumn3.HeaderText = "Цена";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 200;
            // 
            // closeBtn
            // 
            this.closeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.closeBtn.Location = new System.Drawing.Point(226, 321);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(151, 57);
            this.closeBtn.TabIndex = 11;
            this.closeBtn.Text = "Закрыть";
            this.closeBtn.UseVisualStyleBackColor = true;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // PriceF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 390);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ценыDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PriceF";
            this.Text = "PriceF";
            this.Load += new System.EventHandler(this.PriceF_Load);
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ценыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ценыDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MyBD_VerbitskiyKurDataSet myBD_VerbitskiyKurDataSet;
        private System.Windows.Forms.BindingSource ценыBindingSource;
        private MyBD_VerbitskiyKurDataSetTableAdapters.ЦеныTableAdapter ценыTableAdapter;
        private MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView ценыDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button closeBtn;
    }
}