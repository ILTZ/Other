﻿namespace WindowsFormsApp1
{
    partial class addSForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.catLB = new System.Windows.Forms.ListBox();
            this.категориятоваровBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.myBD_VerbitskiyKurDataSet = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSet();
            this.clientLB = new System.Windows.Forms.ListBox();
            this.клиентыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.descrTB = new System.Windows.Forms.TextBox();
            this.summTB = new System.Windows.Forms.TextBox();
            this.comTB = new System.Windows.Forms.TextBox();
            this.dateP = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.addBtn = new System.Windows.Forms.Button();
            this.closeBtn = new System.Windows.Forms.Button();
            this.сдача_в_ломбардBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.сдача_в_ломбардTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.Сдача_в_ломбардTableAdapter();
            this.tableAdapterManager = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager();
            this.категория_товаровTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.Категория_товаровTableAdapter();
            this.клиентыTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.КлиентыTableAdapter();
            this.продажиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.продажиTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.ПродажиTableAdapter();
            this.ценыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ценыTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.ЦеныTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.категориятоваровBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.сдача_в_ломбардBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.продажиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ценыBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // catLB
            // 
            this.catLB.DataSource = this.категориятоваровBindingSource;
            this.catLB.DisplayMember = "Название";
            this.catLB.FormattingEnabled = true;
            this.catLB.Location = new System.Drawing.Point(12, 47);
            this.catLB.Name = "catLB";
            this.catLB.Size = new System.Drawing.Size(246, 95);
            this.catLB.TabIndex = 0;
            this.catLB.ValueMember = "Код_категории";
            this.catLB.SelectedIndexChanged += new System.EventHandler(this.catLB_SelectedIndexChanged);
            // 
            // категориятоваровBindingSource
            // 
            this.категориятоваровBindingSource.DataMember = "Категория_товаров";
            this.категориятоваровBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // myBD_VerbitskiyKurDataSet
            // 
            this.myBD_VerbitskiyKurDataSet.DataSetName = "MyBD_VerbitskiyKurDataSet";
            this.myBD_VerbitskiyKurDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // clientLB
            // 
            this.clientLB.DataSource = this.клиентыBindingSource;
            this.clientLB.DisplayMember = "Фамилия";
            this.clientLB.FormattingEnabled = true;
            this.clientLB.Location = new System.Drawing.Point(12, 183);
            this.clientLB.Name = "clientLB";
            this.clientLB.Size = new System.Drawing.Size(246, 95);
            this.clientLB.TabIndex = 1;
            this.clientLB.ValueMember = "Код_клиента";
            // 
            // клиентыBindingSource
            // 
            this.клиентыBindingSource.DataMember = "Клиенты";
            this.клиентыBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // descrTB
            // 
            this.descrTB.Location = new System.Drawing.Point(451, 47);
            this.descrTB.Name = "descrTB";
            this.descrTB.Size = new System.Drawing.Size(195, 20);
            this.descrTB.TabIndex = 2;
            // 
            // summTB
            // 
            this.summTB.Location = new System.Drawing.Point(451, 73);
            this.summTB.Name = "summTB";
            this.summTB.Size = new System.Drawing.Size(195, 20);
            this.summTB.TabIndex = 3;
            // 
            // comTB
            // 
            this.comTB.Location = new System.Drawing.Point(451, 99);
            this.comTB.Name = "comTB";
            this.comTB.Size = new System.Drawing.Size(195, 20);
            this.comTB.TabIndex = 4;
            // 
            // dateP
            // 
            this.dateP.Location = new System.Drawing.Point(281, 258);
            this.dateP.Name = "dateP";
            this.dateP.Size = new System.Drawing.Size(200, 20);
            this.dateP.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 35);
            this.label1.TabIndex = 8;
            this.label1.Text = "Категория";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(246, 35);
            this.label2.TabIndex = 9;
            this.label2.Text = "Клиент";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(277, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 35);
            this.label3.TabIndex = 10;
            this.label3.Text = "Описание";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(277, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 35);
            this.label4.TabIndex = 11;
            this.label4.Text = "Сумма";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(277, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 35);
            this.label5.TabIndex = 12;
            this.label5.Text = "Комиссионные";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(317, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 35);
            this.label6.TabIndex = 13;
            this.label6.Text = "Дата";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // addBtn
            // 
            this.addBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addBtn.Location = new System.Drawing.Point(12, 416);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(151, 57);
            this.addBtn.TabIndex = 14;
            this.addBtn.Text = "Добавить";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.closeBtn.Location = new System.Drawing.Point(495, 416);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(151, 57);
            this.closeBtn.TabIndex = 15;
            this.closeBtn.Text = "Закрыть";
            this.closeBtn.UseVisualStyleBackColor = true;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // сдача_в_ломбардBindingSource
            // 
            this.сдача_в_ломбардBindingSource.DataMember = "Сдача_в_ломбард";
            this.сдача_в_ломбардBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // сдача_в_ломбардTableAdapter
            // 
            this.сдача_в_ломбардTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.Категория_товаровTableAdapter = this.категория_товаровTableAdapter;
            this.tableAdapterManager.КлиентыTableAdapter = this.клиентыTableAdapter;
            this.tableAdapterManager.ПродажиTableAdapter = null;
            this.tableAdapterManager.Сдача_в_ломбардTableAdapter = this.сдача_в_ломбардTableAdapter;
            this.tableAdapterManager.ЦеныTableAdapter = null;
            // 
            // категория_товаровTableAdapter
            // 
            this.категория_товаровTableAdapter.ClearBeforeFill = true;
            // 
            // клиентыTableAdapter
            // 
            this.клиентыTableAdapter.ClearBeforeFill = true;
            // 
            // продажиBindingSource
            // 
            this.продажиBindingSource.DataMember = "Продажи";
            this.продажиBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // продажиTableAdapter
            // 
            this.продажиTableAdapter.ClearBeforeFill = true;
            // 
            // ценыBindingSource
            // 
            this.ценыBindingSource.DataMember = "Цены";
            this.ценыBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // ценыTableAdapter
            // 
            this.ценыTableAdapter.ClearBeforeFill = true;
            // 
            // addSForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(666, 484);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateP);
            this.Controls.Add(this.comTB);
            this.Controls.Add(this.summTB);
            this.Controls.Add(this.descrTB);
            this.Controls.Add(this.clientLB);
            this.Controls.Add(this.catLB);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "addSForm";
            this.Text = "Добавить";
            this.Load += new System.EventHandler(this.addSForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.категориятоваровBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.сдача_в_ломбардBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.продажиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ценыBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox catLB;
        private System.Windows.Forms.ListBox clientLB;
        private System.Windows.Forms.TextBox descrTB;
        private System.Windows.Forms.TextBox summTB;
        private System.Windows.Forms.TextBox comTB;
        private System.Windows.Forms.DateTimePicker dateP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button closeBtn;
        private MyBD_VerbitskiyKurDataSet myBD_VerbitskiyKurDataSet;
        private System.Windows.Forms.BindingSource сдача_в_ломбардBindingSource;
        private MyBD_VerbitskiyKurDataSetTableAdapters.Сдача_в_ломбардTableAdapter сдача_в_ломбардTableAdapter;
        private MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private MyBD_VerbitskiyKurDataSetTableAdapters.Категория_товаровTableAdapter категория_товаровTableAdapter;
        private System.Windows.Forms.BindingSource категориятоваровBindingSource;
        private MyBD_VerbitskiyKurDataSetTableAdapters.КлиентыTableAdapter клиентыTableAdapter;
        private System.Windows.Forms.BindingSource клиентыBindingSource;
        private System.Windows.Forms.BindingSource продажиBindingSource;
        private MyBD_VerbitskiyKurDataSetTableAdapters.ПродажиTableAdapter продажиTableAdapter;
        private System.Windows.Forms.BindingSource ценыBindingSource;
        private MyBD_VerbitskiyKurDataSetTableAdapters.ЦеныTableAdapter ценыTableAdapter;
    }
}