﻿namespace WindowsFormsApp1
{
    partial class statForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.closeBtn = new System.Windows.Forms.Button();
            this.myBD_VerbitskiyKurDataSet = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSet();
            this.maxSumViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.maxSumViewTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.maxSumViewTableAdapter();
            this.tableAdapterManager = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager();
            this.maxSumViewDataGridView = new System.Windows.Forms.DataGridView();
            this.sumComBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sumComTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.sumComTableAdapter();
            this.sumComDataGridView = new System.Windows.Forms.DataGridView();
            this.sumViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sumViewTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.sumViewTableAdapter();
            this.sumViewDataGridView = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxSumViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxSumViewDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumComBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumComDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumViewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumViewDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // closeBtn
            // 
            this.closeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.closeBtn.Location = new System.Drawing.Point(206, 394);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(151, 57);
            this.closeBtn.TabIndex = 15;
            this.closeBtn.Text = "Закрыть";
            this.closeBtn.UseVisualStyleBackColor = true;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // myBD_VerbitskiyKurDataSet
            // 
            this.myBD_VerbitskiyKurDataSet.DataSetName = "MyBD_VerbitskiyKurDataSet";
            this.myBD_VerbitskiyKurDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // maxSumViewBindingSource
            // 
            this.maxSumViewBindingSource.DataMember = "maxSumView";
            this.maxSumViewBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // maxSumViewTableAdapter
            // 
            this.maxSumViewTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.Категория_товаровTableAdapter = null;
            this.tableAdapterManager.КлиентыTableAdapter = null;
            this.tableAdapterManager.ПродажиTableAdapter = null;
            this.tableAdapterManager.Сдача_в_ломбардTableAdapter = null;
            this.tableAdapterManager.ЦеныTableAdapter = null;
            // 
            // maxSumViewDataGridView
            // 
            this.maxSumViewDataGridView.AutoGenerateColumns = false;
            this.maxSumViewDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.maxSumViewDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.maxSumViewDataGridView.DataSource = this.maxSumViewBindingSource;
            this.maxSumViewDataGridView.Location = new System.Drawing.Point(12, 47);
            this.maxSumViewDataGridView.Name = "maxSumViewDataGridView";
            this.maxSumViewDataGridView.Size = new System.Drawing.Size(548, 67);
            this.maxSumViewDataGridView.TabIndex = 16;
            // 
            // sumComBindingSource
            // 
            this.sumComBindingSource.DataMember = "sumCom";
            this.sumComBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // sumComTableAdapter
            // 
            this.sumComTableAdapter.ClearBeforeFill = true;
            // 
            // sumComDataGridView
            // 
            this.sumComDataGridView.AutoGenerateColumns = false;
            this.sumComDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sumComDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3});
            this.sumComDataGridView.DataSource = this.sumComBindingSource;
            this.sumComDataGridView.Location = new System.Drawing.Point(17, 176);
            this.sumComDataGridView.Name = "sumComDataGridView";
            this.sumComDataGridView.Size = new System.Drawing.Size(548, 71);
            this.sumComDataGridView.TabIndex = 16;
            // 
            // sumViewBindingSource
            // 
            this.sumViewBindingSource.DataMember = "sumView";
            this.sumViewBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // sumViewTableAdapter
            // 
            this.sumViewTableAdapter.ClearBeforeFill = true;
            // 
            // sumViewDataGridView
            // 
            this.sumViewDataGridView.AutoGenerateColumns = false;
            this.sumViewDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sumViewDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4});
            this.sumViewDataGridView.DataSource = this.sumViewBindingSource;
            this.sumViewDataGridView.Location = new System.Drawing.Point(17, 308);
            this.sumViewDataGridView.Name = "sumViewDataGridView";
            this.sumViewDataGridView.Size = new System.Drawing.Size(548, 71);
            this.sumViewDataGridView.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(556, 35);
            this.label1.TabIndex = 17;
            this.label1.Text = "Самый дорогой товар";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(556, 35);
            this.label2.TabIndex = 18;
            this.label2.Text = "Сумма комиссионных";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(12, 270);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(556, 35);
            this.label3.TabIndex = 19;
            this.label3.Text = "Сумма выданных средств";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Сумма";
            this.dataGridViewTextBoxColumn1.HeaderText = "Сумма";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 250;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Название";
            this.dataGridViewTextBoxColumn2.HeaderText = "Название";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 250;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Сумма_комиссионных";
            this.dataGridViewTextBoxColumn3.HeaderText = "Сумма_комиссионных";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 500;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Сумма_выданных_средств";
            this.dataGridViewTextBoxColumn4.HeaderText = "Сумма_выданных_средств";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 500;
            // 
            // statForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 467);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.sumViewDataGridView);
            this.Controls.Add(this.sumComDataGridView);
            this.Controls.Add(this.maxSumViewDataGridView);
            this.Controls.Add(this.closeBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "statForm";
            this.Text = "Статистика";
            this.Load += new System.EventHandler(this.Статистика_Load);
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxSumViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxSumViewDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumComBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumComDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumViewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumViewDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button closeBtn;
        private MyBD_VerbitskiyKurDataSet myBD_VerbitskiyKurDataSet;
        private System.Windows.Forms.BindingSource maxSumViewBindingSource;
        private MyBD_VerbitskiyKurDataSetTableAdapters.maxSumViewTableAdapter maxSumViewTableAdapter;
        private MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView maxSumViewDataGridView;
        private System.Windows.Forms.BindingSource sumComBindingSource;
        private MyBD_VerbitskiyKurDataSetTableAdapters.sumComTableAdapter sumComTableAdapter;
        private System.Windows.Forms.DataGridView sumComDataGridView;
        private System.Windows.Forms.BindingSource sumViewBindingSource;
        private MyBD_VerbitskiyKurDataSetTableAdapters.sumViewTableAdapter sumViewTableAdapter;
        private System.Windows.Forms.DataGridView sumViewDataGridView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}