﻿namespace WindowsFormsApp1
{
    partial class addCatgoryF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.myBD_VerbitskiyKurDataSet = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSet();
            this.категория_товаровBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.категория_товаровTableAdapter = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.Категория_товаровTableAdapter();
            this.tableAdapterManager = new WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager();
            this.nameTB = new System.Windows.Forms.TextBox();
            this.descTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.addBtn = new System.Windows.Forms.Button();
            this.closeBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.категория_товаровBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // myBD_VerbitskiyKurDataSet
            // 
            this.myBD_VerbitskiyKurDataSet.DataSetName = "MyBD_VerbitskiyKurDataSet";
            this.myBD_VerbitskiyKurDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // категория_товаровBindingSource
            // 
            this.категория_товаровBindingSource.DataMember = "Категория_товаров";
            this.категория_товаровBindingSource.DataSource = this.myBD_VerbitskiyKurDataSet;
            // 
            // категория_товаровTableAdapter
            // 
            this.категория_товаровTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp1.MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.Категория_товаровTableAdapter = this.категория_товаровTableAdapter;
            this.tableAdapterManager.КлиентыTableAdapter = null;
            this.tableAdapterManager.ПродажиTableAdapter = null;
            this.tableAdapterManager.Сдача_в_ломбардTableAdapter = null;
            this.tableAdapterManager.ЦеныTableAdapter = null;
            // 
            // nameTB
            // 
            this.nameTB.Location = new System.Drawing.Point(197, 18);
            this.nameTB.Name = "nameTB";
            this.nameTB.Size = new System.Drawing.Size(213, 20);
            this.nameTB.TabIndex = 0;
            // 
            // descTB
            // 
            this.descTB.Location = new System.Drawing.Point(197, 60);
            this.descTB.Name = "descTB";
            this.descTB.Size = new System.Drawing.Size(213, 20);
            this.descTB.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 34);
            this.label1.TabIndex = 12;
            this.label1.Text = "Название";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(170, 34);
            this.label2.TabIndex = 13;
            this.label2.Text = "Примечание";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // addBtn
            // 
            this.addBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addBtn.Location = new System.Drawing.Point(12, 217);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(151, 57);
            this.addBtn.TabIndex = 14;
            this.addBtn.Text = "Добавить";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.closeBtn.Location = new System.Drawing.Point(273, 217);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(151, 57);
            this.closeBtn.TabIndex = 15;
            this.closeBtn.Text = "Закрыть";
            this.closeBtn.UseVisualStyleBackColor = true;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // addCatgoryF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 286);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.addBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.descTB);
            this.Controls.Add(this.nameTB);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "addCatgoryF";
            this.Text = "Добавление категории";
            this.Load += new System.EventHandler(this.addCatgoryF_Load);
            ((System.ComponentModel.ISupportInitialize)(this.myBD_VerbitskiyKurDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.категория_товаровBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MyBD_VerbitskiyKurDataSet myBD_VerbitskiyKurDataSet;
        private System.Windows.Forms.BindingSource категория_товаровBindingSource;
        private MyBD_VerbitskiyKurDataSetTableAdapters.Категория_товаровTableAdapter категория_товаровTableAdapter;
        private MyBD_VerbitskiyKurDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox nameTB;
        private System.Windows.Forms.TextBox descTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button addBtn;
        private System.Windows.Forms.Button closeBtn;
    }
}