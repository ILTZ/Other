﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{
    public partial class ClientsF : Form
    {
        public ClientsF()
        {
            InitializeComponent();
        }

        private void клиентыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.клиентыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.myBD_VerbitskiyKurDataSet);

        }

        private void ClientsF_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Клиенты);

        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            Form f = new addClientBtn();
            f.ShowDialog();
        }

        private void ClientsF_Activated(object sender, EventArgs e)
        {
            updateGV();
        }

        System.Threading.Mutex mutex = new System.Threading.Mutex();
        void updateGV()
        {
            mutex.WaitOne();

            this.клиентыTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Клиенты);
            клиентыDataGridView.Refresh();

            mutex.ReleaseMutex();

        }

        bool deleteLineOnID(int _id)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\MyBD_VerbitskiyKur.mdf;Integrated Security=True;Connect Timeout=30");

            SqlCommand cmd = new SqlCommand($"DELETE FROM Клиенты WHERE Код_клиента = {Convert.ToString(_id)}");
            cmd.Connection = con;

            con.Open();
            try
            {
                int x = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось удалить запись!");
                con.Close();
                return false;
            }
            con.Close();



            return true;
        }


        private void deleteBtn_Click(object sender, EventArgs e)
        {
            int curID = 0;

            try
            {
                curID = Convert.ToInt32(клиентыDataGridView.CurrentRow.Cells[0].Value);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Выберете строку!");
                return;
            }

            DialogResult d = MessageBox.Show("Вы действительно хотите удалить эту запись?", "Удаление", MessageBoxButtons.YesNo);
            
            if (d == DialogResult.Yes)
            {
                if (deleteLineOnID(curID));
                {
                    updateGV();
                }
            }

        }

        private void клиентыDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
