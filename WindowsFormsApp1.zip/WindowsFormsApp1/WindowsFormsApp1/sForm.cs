﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{
    public partial class sForm : Form
    {
        public sForm()
        {
            InitializeComponent();
        }

        private void sForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.normSdacha". При необходимости она может быть перемещена или удалена.
            this.normSdachaTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.normSdacha);

        }

        bool removeFromTableOnID(int _id)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\MyBD_VerbitskiyKur.mdf;Integrated Security=True;Connect Timeout=30");

            SqlCommand cmd = new SqlCommand($"DELETE FROM Продажи WHERE Код_сдачи = {Convert.ToString(_id)}");
            cmd.Connection = con;

            con.Open();

            int i = cmd.ExecuteNonQuery();

            cmd.CommandText = ($"DELETE FROM Сдача_в_ломбард WHERE Код_сдачи = {Convert.ToString(_id)}");
            int b = cmd.ExecuteNonQuery();

            cmd.CommandText = ($"DELETE FROM Цены WHERE Код_сдачи = {Convert.ToString(_id)}");
            int a = cmd.ExecuteNonQuery();

            con.Close();

            return true;
        }


        private void addBtn_Click(object sender, EventArgs e)
        {
            Form f = new addSForm();
            f.ShowDialog();
        }

        private void delBtn_Click(object sender, EventArgs e)
        {
            int curID = 0;

            try
            {
                curID = Convert.ToInt32(normSdachaDataGridView.CurrentRow.Cells[0].Value);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Выберите строку!");
                return;
            }




            DialogResult d = MessageBox.Show("Вы действительно хотите удалить эту запись?", "Удаление", MessageBoxButtons.YesNo);

            if (d == DialogResult.Yes)
            {
                try
                {

                    if (removeFromTableOnID(curID));
                    {
                        normSdachaDataGridView.Rows.RemoveAt(normSdachaDataGridView.CurrentRow.Index);
                        normSdachaDataGridView.Refresh();
                    }
                }
                catch
                {
                    MessageBox.Show("Не выбрана строка для удаления!");
                }
            }
        }

        private void statBtn_Click(object sender, EventArgs e)
        {
            Form f = new statForm();
            f.ShowDialog();
        }

        private void sortBtn_Click(object sender, EventArgs e)
        {
            DataGridViewColumn col = new DataGridViewColumn();

            switch (critLB.SelectedIndex)
            {
                case 0:
                    col = dataGridViewTextBoxColumn2;
                    break;

                case 1:
                    col = dataGridViewTextBoxColumn8;
                    break;

                case 2:
                    col = dataGridViewTextBoxColumn9;
                    break;
            }

            if (upRB.Checked)
            {
                normSdachaDataGridView.Sort(col, System.ComponentModel.ListSortDirection.Ascending);
            }
            else
            {
                normSdachaDataGridView.Sort(col, System.ComponentModel.ListSortDirection.Descending);
            }



        }

        private void critLB_SelectedIndexChanged(object sender, EventArgs e)
        {
            sortBtn.Enabled = true;
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void sForm_Activated(object sender, EventArgs e)
        {
            this.normSdachaTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.normSdacha);
            normSdachaDataGridView.Refresh();
        }
    }
}
