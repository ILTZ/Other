﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class addSForm : Form
    {
        public addSForm()
        {
            InitializeComponent();
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        int findMaxID()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\MyBD_VerbitskiyKur.mdf;Integrated Security=True;Connect Timeout=30");

            SqlCommand cmd = new SqlCommand(@"SELECT MAX(Код_сдачи) FROM dbo.Продажи");
            cmd.Connection = con;

            int max = 0;
            con.Open();
            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    max = dr.GetInt32(0);
                }
            }
            con.Close();

            return max;
        }


        private void addBtn_Click(object sender, EventArgs e)
        {
            int max = findMaxID();

            MyBD_VerbitskiyKurDataSet.ПродажиRow r = this.myBD_VerbitskiyKurDataSet.Продажи.NewПродажиRow();
            r.Код_сдачи = (max + 1);
            r.Дата = dateP.Value;
            r.Цена = (decimal)Convert.ToDouble(summTB.Text);
            this.myBD_VerbitskiyKurDataSet.Продажи.AddПродажиRow(r);

            MyBD_VerbitskiyKurDataSet.ЦеныRow c = this.myBD_VerbitskiyKurDataSet.Цены.NewЦеныRow();
            c.Код_сдачи = max + 1;
            c.Цена = (decimal)Convert.ToDouble(summTB.Text);
            c.Дата = dateP.Value;
            this.myBD_VerbitskiyKurDataSet.Цены.AddЦеныRow(c);


            MyBD_VerbitskiyKurDataSet.Сдача_в_ломбардRow row = this.myBD_VerbitskiyKurDataSet.Сдача_в_ломбард.NewСдача_в_ломбардRow();

            row.Код_сдачи = max + 1;
            row.Категория = (int)catLB.SelectedValue;
            row.Код_клиента = (int)clientLB.SelectedValue;
            row.Описание = descrTB.Text;
            row.Дата_сдачи = dateP.Value;
            row.Сумма_на_руки = (decimal)Convert.ToDouble(summTB.Text);
            row.Комиссионные = (decimal)Convert.ToDouble(comTB.Text);

            int x = row.Код_сдачи;

            this.myBD_VerbitskiyKurDataSet.Сдача_в_ломбард.AddСдача_в_ломбардRow(row);


            ценыTableAdapter.Update(this.myBD_VerbitskiyKurDataSet.Цены);
            сдача_в_ломбардTableAdapter.Update(this.myBD_VerbitskiyKurDataSet.Сдача_в_ломбард);
            продажиTableAdapter.Update(this.myBD_VerbitskiyKurDataSet.Продажи);

            this.Close();
        }

        private void сдача_в_ломбардBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.сдача_в_ломбардBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.myBD_VerbitskiyKurDataSet);

        }

        private void сдача_в_ломбардBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.сдача_в_ломбардBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.myBD_VerbitskiyKurDataSet);

        }

        private void addSForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.Цены". При необходимости она может быть перемещена или удалена.
            this.ценыTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Цены);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.Продажи". При необходимости она может быть перемещена или удалена.
            this.продажиTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Продажи);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Клиенты);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.Категория_товаров". При необходимости она может быть перемещена или удалена.
            this.категория_товаровTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Категория_товаров);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.Сдача_в_ломбард". При необходимости она может быть перемещена или удалена.
            this.сдача_в_ломбардTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Сдача_в_ломбард);

        }

        private void catLB_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
