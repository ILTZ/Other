﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class CategoryF : Form
    {
        public CategoryF()
        {
            InitializeComponent();
        }

        private void категория_товаровBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.категория_товаровBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.myBD_VerbitskiyKurDataSet);

        }

        private void CategoryF_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.Категория_товаров". При необходимости она может быть перемещена или удалена.
            this.категория_товаровTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Категория_товаров);

        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CategoryF_Activated(object sender, EventArgs e)
        {
            this.категория_товаровTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Категория_товаров);
            категория_товаровDataGridView.Refresh();

        }

        private void addBtn_Click(object sender, EventArgs e)
        {
            Form f = new addCatgoryF();
            f.ShowDialog();
        }

        bool removeFromTableOnID(int _id)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\MyBD_VerbitskiyKur.mdf;Integrated Security=True;Connect Timeout=30");

            SqlCommand cmd = new SqlCommand($"DELETE FROM Категория_товаров WHERE Код_категории = {Convert.ToString(_id)}");
            cmd.Connection = con;

            con.Open();

            try
            {
                int x = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                con.Close();
                return false;
            }

            con.Close();


            return true;
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            int curID = 0;


            try
            {
                curID = Convert.ToInt32(категория_товаровDataGridView.CurrentRow.Cells[0].Value);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Выберите ячейку!");
                return;
            }


            DialogResult d = MessageBox.Show("Вы действительно хотите удалить эту запись?", "Удаление", MessageBoxButtons.YesNo);

            if (d == DialogResult.Yes)
            {
                try
                {
                    if (removeFromTableOnID(curID)) ;
                    {
                        this.категория_товаровTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Категория_товаров);
                        категория_товаровDataGridView.Refresh();
                    }
                }
                catch
                {
                    MessageBox.Show("Не выбрана строка для удаления!");
                }
            }
        }
    }
}
