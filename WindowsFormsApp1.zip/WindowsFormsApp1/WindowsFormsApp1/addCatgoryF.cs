﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class addCatgoryF : Form
    {
        public addCatgoryF()
        {
            InitializeComponent();
        }

        private void категория_товаровBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.категория_товаровBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.myBD_VerbitskiyKurDataSet);

        }

        private void addCatgoryF_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.Категория_товаров". При необходимости она может быть перемещена или удалена.
            this.категория_товаровTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.Категория_товаров);

        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        int getMaxID()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\MyBD_VerbitskiyKur.mdf;Integrated Security=True;Connect Timeout=30");

            SqlCommand cmd = new SqlCommand($"SELECT MAX(Код_категории) FROM Категория_товаров");
            cmd.Connection = con;

            con.Open();

            int id = 0;

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    id = reader.GetInt32(0);
                }
            }

            con.Close();

            return id;
        }


        private void addBtn_Click(object sender, EventArgs e)
        {
            MyBD_VerbitskiyKurDataSet.Категория_товаровRow r = this.myBD_VerbitskiyKurDataSet.Категория_товаров.NewКатегория_товаровRow();

            if (getMaxID() != 0)
            {
                r.Код_категории = getMaxID() + 1;
                r.Название = nameTB.Text;
                r.Примечание = descTB.Text;

                myBD_VerbitskiyKurDataSet.Категория_товаров.AddКатегория_товаровRow(r);
                категория_товаровTableAdapter.Update(myBD_VerbitskiyKurDataSet.Категория_товаров);
            }
            else
            {
                MessageBox.Show("Error!");
            }


            this.Close();
        }
    }
}
