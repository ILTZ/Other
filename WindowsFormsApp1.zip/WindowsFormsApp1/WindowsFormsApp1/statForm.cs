﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class statForm : Form
    {
        public statForm()
        {
            InitializeComponent();
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Статистика_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.sumView". При необходимости она может быть перемещена или удалена.
            this.sumViewTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.sumView);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.sumCom". При необходимости она может быть перемещена или удалена.
            this.sumComTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.sumCom);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "myBD_VerbitskiyKurDataSet.maxSumView". При необходимости она может быть перемещена или удалена.
            this.maxSumViewTableAdapter.Fill(this.myBD_VerbitskiyKurDataSet.maxSumView);

        }
    }
}
