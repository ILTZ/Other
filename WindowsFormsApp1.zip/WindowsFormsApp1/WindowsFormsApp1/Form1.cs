﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void sdachaBtn_Click(object sender, EventArgs e)
        {
            Form f = new sForm();
            f.ShowDialog();
        }

        private void PriceBtn_Click(object sender, EventArgs e)
        {
            Form f = new PriceF();
            f.ShowDialog();
        }

        private void ClientsBtn_Click(object sender, EventArgs e)
        {
            Form f = new ClientsF();
            f.ShowDialog();
        }

        private void CategoryBtn_Click(object sender, EventArgs e)
        {
            Form f = new CategoryF();
            f.ShowDialog();
        }
    }
}
